#!/bin/bash

# Bash Script for nucleosome dynamics package based on docker


docker run -v /Users/simon/GitProjects/nucleosome_dynamics:/project_dir/ nucdyn_edit  run /project_dir/test/scripts/wf-test2.sh 
# 
# ##################
# for SAMPLE in cellcycleG2_chrII
# do
# 
# ##################
# # read bam
# docker run -v /Users/simon/GitProjects/nucleosome_dynamics:/project_dir/ nucdyn_edit readBAM \
# 	--input /project_dir/test/data/$SAMPLE.bam \
# 	--output /project_dir/test/data/$SAMPLE.RData \
# 	--type paired
# 
# ##################
# # detect nucleosomes with nucleR
# docker run -v /Users/simon/GitProjects/nucleosome_dynamics:/project_dir/ nucdyn_edit nucleR \
# 	--input /project_dir/test/data/$SAMPLE.RData \
# 	--output /project_dir/test/data/$SAMPLE.gff \
# 	--type paired
# # 
# # docker run -v /Users/simon/GitProjects/nucleosome_dynamics:/project_dir/ nucdyn_edit nucleR_stats \
# # 	--input /project_dir/2_pipeline/06_NucleosomeDynamics/nucleR/$SAMPLE.gff \
# # 	--genome /project_dir/0_data/reference/pf_nucDyn.gff\
# # 	--out_genes /project_dir/2_pipeline/06_NucleosomeDynamics/statistics/nucleR/$SAMPLE''_genes.csv \
# # 	--out_gw /project_dir/2_pipeline/06_NucleosomeDynamics/statistics/nucleR/$SAMPLE''_genome.csv
# 
# ##################
# # detect NFRs
# docker run -v /Users/simon/GitProjects/nucleosome_dynamics:/project_dir/ nucdyn_edit NFR \
# 	--input /project_dir/test/data/$SAMPLE.gff \
# 	--output /project_dir/test/data/$SAMPLE''_NFR.gff 
# #
# # docker run -v /Users/simon/GitProjects/nucleosome_dynamics:/project_dir/ nucdyn_edit NFR_stats \
# # 	--input /project_dir/2_pipeline/06_NucleosomeDynamics/NFR/$SAMPLE.gff \
# # 	--genome /project_dir/0_data/reference/pf_nucDyn.gff\
# # 	--out_gw /project_dir/2_pipeline/06_NucleosomeDynamics/statistics/NFR/$SAMPLE''_genome.csv
# 
# ##################
# # detect Txstart
# docker run -v /Users/simon/GitProjects/nucleosome_dynamics:/project_dir/ nucdyn_edit txstart \
# 	--calls /project_dir/test/data/$SAMPLE.gff \
# 	--genome /project_dir/test/data/refGenomes/R64-1-1/genes.gff \
# 	--output /project_dir/test/data/$SAMPLE''_txstart.gff
# 
# # docker run -v /Users/simon/GitProjects/nucleosome_dynamics:/project_dir/ nucdyn_edit txstart_stats \
# # 	--input /project_dir/2_pipeline/06_NucleosomeDynamics/txstart/$SAMPLE.gff \
# # 	--genome /project_dir/0_data/reference/pf_nucDyn.gff \
# # 	--out_genes /project_dir/2_pipeline/06_NucleosomeDynamics/statistics/txstart/$SAMPLE''_genes.csv \
# # 	--out_gw /project_dir/2_pipeline/06_NucleosomeDynamics/statistics/txstart/$SAMPLE''_genome.png \
# # 	--out_gw2 /project_dir/2_pipeline/06_NucleosomeDynamics/statistics/txstart/$SAMPLE''_genome2.png
# 
# 
# ##################
# # detect periodicity
# docker run -v /Users/simon/GitProjects/nucleosome_dynamics:/project_dir/ nucdyn_edit txstart \
# 	--calls /project_dir/test/data/$SAMPLE.gff \
# 	--genome /project_dir/test/data/refGenomes/R64-1-1/genes.gff \
# 	--output /project_dir/test/data/$SAMPLE''_txstart.gff
# 
# 
# ##################
# # detect stiffness
# done
# 
# 
# ###################
# # detect nucleosome dynamics
# docker run -v /Users/simon/GitProjects/nucleosome_dynamics:/project_dir/ nucdyn_edit nucDyn \
# 	--input2 /project_dir/test/data/cellcycleM_chrII.RData \
# 	--input1 /project_dir/test/data/cellcycleG2_chrII.RData \
# 	--calls2 /project_dir/test/data/cellcycleM_chrII.gff \
# 	--calls1 /project_dir/test/data/cellcycleG2_chrII.gff \
# 	--outputGff /project_dir/test/data/nucDyn.gff \
# 	--outputBigWig /project_dir/test/data/nucDyn.bw  \
# 	--genome /project_dir/test/data/refGenomes/R64-1-1/R64-1-1.fa.chrom.sizes
# 
# # docker run -v /Users/simon/GitProjects/nucleosome_dynamics:/project_dir/ nucdyn_edit nucDyn_stats \
# # 	--input /project_dir/2_pipeline/06_NucleosomeDynamics/NucDyn/24h.gff \
# # 	--genome /project_dir/0_data/reference/pf_nucDyn.gff \
# # 	--out_genes /project_dir/2_pipeline/06_NucleosomeDynamics/statistics/NucDyn/24h_genes.csv \
# # 	--out_gw /project_dir/2_pipeline/06_NucleosomeDynamics/statistics/NucDyn/24h_genome.png
 